<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
            redirect('form_login');
        }
        
        $this->load->model('m_laporan');
    }
    //akses admin
    public function index()
    {
        if($this->session->userdata('role') === 'Admin')
        {
            $data['judul'] = 'Laporan';
            $data['laporanv'] = $this->m_laporan->tampil_data();
            $data['memberv'] = $this->m_laporan->daftarpelanggan();
            $data['outletv'] = $this->m_laporan->daftaroutlet();
            $data['outler1'] = $this->m_laporan->outletx();
            $this->template->load('template','Laporan/v_laporan',$data);
        }
        else if($this->session->userdata('role') === 'Kasir')
        {
            $data['judul'] = 'Laporan';
            $data['laporanv'] = $this->m_laporan->daftartransaksi();
            $this->template->load('template','Laporan/v_laporan',$data);
        }
        else if($this->session->userdata('role') === 'Owner')
        {
            $data['judul'] = 'Laporan';
            $data['laporanv'] = $this->m_laporan->daftartransaksi();
            $this->template->load('template','Laporan/v_laporan',$data);
        }
        else 
        {
            echo "Access Denied" ;
        }
    }


}    