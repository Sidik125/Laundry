<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Outlet extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
            redirect('form_login');
        }
        
        $this->load->model('m_outlet');
    }
    //akses admin
    public function index()
    {
        if($this->session->userdata('role') === 'Admin')
        {
            $data['judul'] = 'Outlet';
            $data['outletv'] = $this->m_outlet->tampil_data();
            $this->template->load('template','Outlet/v_outlet',$data);
        }
        else 
        {
            echo "Access Denied";
        }
    }
    public function add()
    {
        //validasi
        $this->form_validation->set_rules('nama_outlet','Nama Outlet','required|trim');
        $this->form_validation->set_rules('alamat','Alamat','required|trim');
        $this->form_validation->set_rules('tlp','No.Telepon','required|trim');

        if ($this->form_validation->run() == FALSE)
        {
            $data['judul'] = 'Tambah Data Outlet';
            // $data['memberv'] = $this->m_member->tampil_data(); //looping user            
            $this->template->load('template','Outlet/tambah',$data);
        }else {
            // $data = 
            // [
            //     'nama' => htmlspecialchars($this->input->post('nama', true)),
            //     'alamat' => htmlspecialchars($this->input->post('alamat',true)),
            //     'jenis_kelamin' => ($this->input->post('jenis_kelamin',true)),
            //     'tlp' => ($this->input->post('tlp',true))
            // ];


        $this->m_outlet->add_datax($data);
        $this->session->set_flashdata
        ('Outlet', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data Outlet berhasil ditambahkan!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>');
        redirect('Outlet');
        }

    }
    public function ubah($id_outlet)
    {
        $this->form_validation->set_rules('nama_outlet','Nama Outlet','required|trim');
        $this->form_validation->set_rules('alamat','Alamat','required|trim');
        $this->form_validation->set_rules('tlp','No.Telepon','required|trim');

        if ($this->form_validation->run() == FALSE) 
        {
            $data['judul'] = 'Perbarui Data Outlet';
            // $data['outlet'] = $this->m_user->daftar_outlet(); //looping outlet   
            $data['outlet'] = $this->m_outlet->edit($id_outlet); //looping edit data tb_user based on id
            $this->template->load('template','Outlet/ubah',$data);
        }else{
            $this->m_outlet->ubahx($id_outlet);
            $this->session->set_flashdata
            ('Outlet','<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data Outlet berhasil diperbarui!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
            </div>');
            redirect('Outlet');
        }
    }


    //delete data
    public function hapus()
    {
        $id_outlet = $this->input->post('hapus');
        $this->m_outlet->hapusx($id_outlet);
        $this->session->set_flashdata
        ('Outlet','<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data Outlet berhasil dihapus!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>');
        redirect('Outlet');
    }


}    