<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('model_data');
	}
	public function index()
	{
		$this->load->view('form_login');
	}
    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login');
    }
	public function masuk()
	{
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]');
		$this->form_validation->set_message('required', 'Kolom tidak boleh kosong!');
		$this->form_validation->set_message('min_length', 'Kata sandi harus antara 3 dan 10 karakter!');

		$email = $this->input->post('email',TRUE);
		$password = md5($this->input->post('password',TRUE));
		$validate = $this->model_data->validate($email,$password);
		if($this->form_validation->run() != false)
		{

			if ($validate->num_rows() > 0) 
			{
				$data  = $validate->row_array();
				$id    = $data['id'];
				$nama  = $data['nama'];
				$email = $data['username'];
				$role  = $data['role'];
				$sesdata = array(
					'id' => $id,
					'nama' => $nama,
					'username' => $email,
					'role' => $role,
					'status_login' => TRUE
				);
				$this->session->set_userdata($sesdata);
				// true admin
				if($role === 'Admin')
				{
					redirect('User');
				}
				// true kasir
				elseif($role === 'Kasir')
				{
					redirect('Pelanggan');
				}
				// false owner
				else
				{
					redirect('Laporan');
				}
			}
			else
			{
				echo $this->session->set_flashdata('message',
				'<div class="alert alert-danger alert-dismissible fade show" role="alert">
					Email atau Password salah!
					<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
				 </div>');
				redirect('login');
			}

		}
		else
		{
			$this->load->view('form_login');
		}

	}
}