<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pelanggan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
            redirect('form_login');
        }
        
        $this->load->model('m_pelanggan');
    }
    //akses admin
    public function index()
    {
        if($this->session->userdata('role') === 'Admin')
        {
            $data['judul'] = 'Data Pelanggan';
            $data['memberv'] = $this->m_pelanggan->tampil_data();
            $this->template->load('template','Pelanggan/v_pelanggan',$data);
        }
        else if($this->session->userdata('role') === 'Kasir')
        {
            
            $data['judul'] = 'Data Pelanggan';
            $data['memberv'] = $this->m_pelanggan->tampil_data();
            $this->template->load('template','Pelanggan/v_pelanggan',$data);
        
        }
        else 
        {
            echo "Access Denied";
        }
    }
    public function member_tambah()
    {
        //validasi
        $this->form_validation->set_rules('nama_member','Nama','required|trim');
        $this->form_validation->set_rules('alamat','Alamat','required|trim');
        $this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required|trim');
        $this->form_validation->set_rules('tlp','No.Telepon','required|trim');

        if ($this->form_validation->run() == FALSE)
        {
            $data['judul'] = 'Tambah Data Member';
            // $data['memberv'] = $this->m_member->tampil_data(); //looping user            
            $this->template->load('template','Pelanggan/tambah_pelanggan',$data);
        }else {
            // $data = 
            // [
            //     'nama' => htmlspecialchars($this->input->post('nama', true)),
            //     'alamat' => htmlspecialchars($this->input->post('alamat',true)),
            //     'jenis_kelamin' => ($this->input->post('jenis_kelamin',true)),
            //     'tlp' => ($this->input->post('tlp',true))
            // ];


        $this->m_pelanggan->add_datax($data);
        $this->session->set_flashdata
        ('Pelanggan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data Pelanggan berhasil ditambahkan!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>');
        redirect('Pelanggan');
            }

    }
    public function ubah($id_member)
    {
        $this->form_validation->set_rules('nama_member','Nama','required|trim');
        $this->form_validation->set_rules('alamat','Alamat','required|trim');   
        $this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required|trim');
        $this->form_validation->set_rules('tlp','No.Telepon','required');

        if ($this->form_validation->run() == FALSE) 
        {
            $data['judul'] = 'Perbarui Data Pelanggan';
            // $data['outlet'] = $this->m_user->daftar_outlet(); //looping outlet   
            $data['member'] = $this->m_pelanggan->edit($id_member); //looping edit data tb_user based on id
            $this->template->load('template','Pelanggan/ubah_pelanggan',$data);
        }else{
            $this->m_pelanggan->ubahx($id_member);
            $this->session->set_flashdata
            ('Pelanggan','<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data Pelanggan berhasil diperbarui!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
            </div>');
            redirect('Pelanggan');
        }
    }


    //delete data
    public function hapus()
    {
        $id_member = $this->input->post('hapus');
        $this->m_pelanggan->hapusx($id_member);
        $this->session->set_flashdata
        ('Pelanggan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data Pelanggan berhasil dihapus!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>');
        redirect('Pelanggan');
    }
    

}    