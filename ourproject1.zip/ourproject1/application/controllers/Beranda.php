<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Beranda extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE)
        {
            redirect('login');
        }
    }
    //akses admin
    public function admin()
    {
        if($this->session->userdata('role') === 'Admin')
        {
            $data['judul'] = 'Beranda';
            $this->template->load('template','beranda',$data);
        }
        else 
        {
            echo "Access Denied";
        }
    }
}    