<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//disable right click or inspect element
class User extends CI_Controller 
{
    // private $tabel_user = "tb_user";
    public function __construct()
    {
        parent :: __construct();
        if($this->session->userdata('status_login') !== TRUE){
            redirect('Login');
        }
        $this->load->model('m_user');
    }
    //akses admin
    public function index() 
    {
        if($this->session->userdata('role') === 'Admin')
        {
            $data['judul'] = 'Pengguna';
            $data['userv'] = $this->m_user->tampilkan_data(); //show data table exept admin
            $this->template->load('template','User/v_user',$data);
        }
        else 
        {
            echo "Acces Denied";
        }
    }
    //tambah data
    public function add()
    {
        //validasi
        $this->form_validation->set_rules('nama','Nama','required|trim|min_length[3]|max_length[20]');
        $this->form_validation->set_rules('username','Username','required|trim|is_unique[tb_user.username]',['is_unique' =>'This username already registered!']);
        $this->form_validation->set_rules('password','Password','required|trim|min_length[3]|max_length[12]');
        // $this->form_validation->set_rules('id_outlet','Toko','required');
        $this->form_validation->set_rules('role','Role','required');
        
        if ($this->form_validation->run() == FALSE)
        {
            $data['judul'] = 'Tambah Data Pengguna';
            $data['userv'] = $this->m_user->tampilkan_data(); //looping user            
            $this->template->load('template','User/tambah',$data);
        }else {
            // $data = [
            //     'name' => htmlspecialchars($this->input->post('name', true)),
            //     'email' => htmlspecialchars($email),
            //     'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
            //     'role_id' => 2,
            //     'is_active' => 1,
            //     'date_created' => time()
            // ];
            $data = 
            [
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'username' => htmlspecialchars($this->input->post('username',true)),
                'password' => md5($this->input->post('password',true)),
                'role' => ($this->input->post('role',true))
            ];
    

            $this->m_user->add_data($data);
            $this->session->set_flashdata
            ('user', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data Pengguna berhasil ditambahkan!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
            redirect('User');
        }
    }

    //tambah aksi
    // public function tambah_aksi()
    // {
    //     $data['title'] = 'tumbalx';
    //     $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

    //     $this->_rules();
    //     if ($this->form_validation->run() == false) {
    //         $this->tambah();
    //     } else {
    //         $data = array(
    //             'nama_siswa' => $this->input->post('nama_siswa'),
    //             'kelas_siswa' => $this->input->post('kelas_siswa'),
    //             'alamat_siswa' => $this->input->post('alamat_siswa'),
    //             'nomor_telepon' => $this->input->post('nomor_telepon')
    //         );

    //         $this->tumbal_model->insert_data($data, 'tbl_siswa');
    //         $this->session->set_flashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
    //             data has been added!
    //             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    //                 <span aria-hidden="true">&times;</span>
    //             </button>
    //             </div>');
    //         redirect('tumbal/tumbalx');
    //         // kalo redirect biasakan awal dari controler lalu file isi di dalam folder view
    //     }
    // }
    
    // public function tambah()
    // {
    //     $data['title'] = 'Pengguna';
    //     $data['user'] = $this->db->get_where('tb_user', ['id_user' => $this->session->userdata('id')])->row_array();
    //     $this->template->load('template','v_user',$data);

    // }
    
    //update data
    public function ubah($id_user)
    {
        $this->form_validation->set_rules('nama','Nama','required|trim|min_length[3]|max_length[30]');
        $this->form_validation->set_rules('username','Username','required|trim');   
        // $this->form_validation->set_rules('password','Password','required|trim|min_length[3]|max_length[12]');
        // $this->form_validation->set_rules('id_outlet','Toko','required');
        $this->form_validation->set_rules('role','Role','required');

        if ($this->form_validation->run() == FALSE) 
        {
            $data['judul'] = 'Perbarui Data Pengguna';
            // $data['outlet'] = $this->m_user->daftar_outlet(); //looping outlet   
            $data['user'] = $this->m_user->edit($id_user); //looping edit data tb_user based on id
            $this->template->load('template','User/ubah',$data);
        }else{
            $this->m_user->ubahx($id_user);
            $this->session->set_flashdata
            ('user','<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data Pengguna berhasil diperbarui!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
            </div>');
            redirect('User');
        }
    }

    //delete data
    public function hapus()
    {
        $id_user = $this->input->post('hapus');
        $this->m_user->hapusx($id_user);
        $this->session->set_flashdata
        ('user','<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data Pengguna berhasil dihapus!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>');
        redirect('User');
    }
}