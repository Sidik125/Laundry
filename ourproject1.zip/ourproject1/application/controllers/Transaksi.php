<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transaksi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
            redirect('form_login');
        }
        
        $this->load->model('m_transaksi');
    }
    //akses admin
    public function index()
    {
        if($this->session->userdata('role') === 'Admin')
        {
            $data['judul'] = 'Transaksi';
            $data['transaksiv'] = $this->m_transaksi->tampil_data();
            $this->template->load('template','Transaksi/v_transaksi',$data);
        }
        else if($this->session->userdata('role') === 'Kasir')
        {
            $data['judul'] = 'Transaksi';
            $data['transaksiv'] = $this->m_transaksi->tampil_data();
            $this->template->load('template','Transaksi/v_transaksi',$data);
        }
        else {
            echo "Access Denied";
        }
    }
    public function kilo() //javascript kalkulasi
    {
        $kilo = $_POST['jml_kilo']; //jml_kilo = total_berat
        $paket = $this->m_transaksi->showall('tb_paket',"WHERE id_paket = '$_POST[paket]' ")->row();
        if ($_POST['jml_kilo'] == "") {
            $total="";
        }else{
            $total = $paket->harga * $kilo;
        }
        echo $total;
    }
    public function add()
    {
        //validasi
        $this->form_validation->set_rules('kode_invoice','Kode Invoice','required|trim');
        $this->form_validation->set_rules('id_member','Pelanggan','required|trim');
        $this->form_validation->set_rules('id_outlet','Outlet','required|trim');
        $this->form_validation->set_rules('tgl','Tanggal Transaksi','required|trim');
        // $this->form_validation->set_rules('tgl_ambil','Tanggal Ambil','required|trim');
        // $this->form_validation->set_rules('total_harga','Total Harga','required|trim');
        $this->form_validation->set_rules('status','Status','required|trim');
        $this->form_validation->set_rules('id_paket','Paket','required|trim');
        $this->form_validation->set_rules('jml_kilo','Jumlah Kilo','required|trim');
        if ($this->form_validation->run() == FALSE)
        {
            $data['judul'] = 'Tambah Data Transaksi';
            $data['memberv'] = $this->m_transaksi->daftarpelanggan();
            $data['paketv'] = $this->m_transaksi->daftarpaket();
            $data['outletv'] = $this->m_transaksi->daftaroutlet();
            // No Otomatis
            $qr = $this->m_transaksi->no()->row_array();
            $kode = $qr['kode'];
            $nu = (int) substr($kode, 6,9);
            $nu++;
            $tgl = date('y');
            $data['no'] = "IDK".$tgl.sprintf('%04s',$nu);
            // No Otomatis
            $this->template->load('template','Transaksi/tambah',$data);
        }else {

        $this->m_transaksi->add_datax($data);
        $this->session->set_flashdata
        ('Transaksi', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data Transaksi berhasil ditambahkan!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>');
        redirect('Transaksi');
        }

    }
    public function ubah($id_transaksi)
    {
        $this->form_validation->set_rules('kode_invoice','Kode Invoice','required|trim');
        $this->form_validation->set_rules('id_member','Pelanggan','required|trim');
        $this->form_validation->set_rules('id_outlet','Outlet','required|trim');
        $this->form_validation->set_rules('id_paket','Paket','required|trim');
        $this->form_validation->set_rules('tgl','Tanggal Transaksi','required|trim');
        $this->form_validation->set_rules('tgl_ambil','Tanggal Ambil','required|trim');
        $this->form_validation->set_rules('total_harga','Total Harga','required|trim');
        $this->form_validation->set_rules('status','Status','required|trim');
        $this->form_validation->set_rules('jml_kilo','Jumlah','required|trim');

        if ($this->form_validation->run() == FALSE) 
        {
            $data['judul'] = 'Detail Transaksi';
            // $data['outlet'] = $this->m_user->daftar_outlet(); //looping outlet   
            $data['paketv'] = $this->m_transaksi->daftarpaket();
            $data['transaksiv'] = $this->m_transaksi->edit($id_transaksi); //looping edit data tb_user based on id
            $data['transaksi2'] = $this->m_transaksi->edit2($id_transaksi); //looping edit data tb_user based on id
            $data['transaksi'] = $this->m_transaksi->edit3($id_transaksi); //looping edit data tb_user based on id
            // $data['memberv'] = $this->m_transaksi->daftarpelanggan();
            // $data['outletv'] = $this->m_transaksi->daftaroutlet();

            $this->template->load('template','Transaksi/ubah',$data);
        }else{
            $this->m_transaksi->ubahx($id_transaksi);
            $this->session->set_flashdata
            ('Transaksi','<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data Transaksi berhasil diperbarui!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
            </div>');
            redirect('Transaksi');
        }
    }


}    