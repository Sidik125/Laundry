<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Paket extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
            redirect('form_login');
        }
        
        $this->load->model('m_paket');
    }
    //akses admin
    public function index()
    {
        if($this->session->userdata('role') === 'Admin')
        {
            $data['judul'] = 'Paket';
            $data['paketv'] = $this->m_paket->tampil_data();
            $this->template->load('template','Paket/v_paket',$data);
        }
        else 
        {
            echo "Access Denied";
        }
    }
    public function tambah_paket()
    {
        //validasi
        $this->form_validation->set_rules('jenis','Jenis Paket','required|trim');
        $this->form_validation->set_rules('nama_paket','Nama Paket','required|trim');
        $this->form_validation->set_rules('harga','Harga','required|trim');
        // $this->form_validation->set_rules('id_outlet','Outlet','required|trim',);


        if ($this->form_validation->run() == FALSE)
        {
            $data['judul'] = 'Tambah Data Paket';
            // $data['memberv'] = $this->m_member->tampil_data(); //looping user            
            $this->template->load('template','Paket/tambah',$data);
        }else {
            // $data = 
            // [
            //     'nama' => htmlspecialchars($this->input->post('nama', true)),
            //     'alamat' => htmlspecialchars($this->input->post('alamat',true)),
            //     'jenis_kelamin' => ($this->input->post('jenis_kelamin',true)),
            //     'tlp' => ($this->input->post('tlp',true))
            // ];


        $this->m_paket->addx($data);
        $this->session->set_flashdata
        ('Paket', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data Paket berhasil ditambahkan! 
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>');
        redirect('Paket');
        }

    }
    public function ubah($id_paket)
    {
        $this->form_validation->set_rules('jenis','Jenis Paket','required|trim');
        $this->form_validation->set_rules('nama_paket','Nama Paket','required|trim');
        $this->form_validation->set_rules('harga','Harga','required|trim');

        if ($this->form_validation->run() == FALSE) 
        {
            $data['judul'] = 'Perbarui Data Paket';
            // $data['outlet'] = $this->m_user->daftar_outlet(); //looping outlet   
            $data['paket'] = $this->m_paket->edit($id_paket); //looping edit data tb_user based on id
            $this->template->load('template','Paket/ubah',$data);
        }else{
            $this->m_paket->ubahx($id_paket);
            $this->session->set_flashdata
            ('Paket','<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data Paket berhasil diperbarui!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
            </div>');
            redirect('Paket');
        }
    }

    public function hapus()
    {
        $id_paket = $this->input->post('hapus');
        $this->m_paket->hapusx($id_paket);
        $this->session->set_flashdata
        ('Paket','<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data Paket berhasil dihapus!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>');
        redirect('Paket');
    }


}    