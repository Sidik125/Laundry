<?php
defined('BASEPATH') or exit('No direct script access allowed');

class m_paket extends CI_Model
{
    public function tampil_data()
    {
        $this->db->order_by('id_paket','desc');
        return $this->db->get('tb_paket')->result();
    }
    public function addx($data)
    {
        $data = 
        [
            'jenis' => htmlspecialchars($this->input->post('jenis', true)),
            'nama_paket' => htmlspecialchars($this->input->post('nama_paket',true)),
            'harga' => ($this->input->post('harga',true))

        ];
        $tabel_paket = $this->db->dbprefix('tb_paket');
        if($this->db->insert($tabel_paket,$data))
            {return true;}
        else
            {return false;} 
    }
    public function ubahx($id_paket)
    {
        $data = 
        [
            'jenis' => htmlspecialchars($this->input->post('jenis', true)),
            'nama_paket' => htmlspecialchars($this->input->post('nama_paket',true)),
            'harga' => ($this->input->post('harga',true))
        ];
        // $tb_user = $this->db->dbprefix('tb_user');
        $this->db->where('id_paket',$id_paket);
        if($this->db->update('tb_paket',$data))
           {return true;}
        else
           {return false;}
           

    }
    public function edit($id_paket)
    {
        $this->db->where('id_paket',$id_paket);
        return $this->db->get('tb_paket')->row_array();
    }

    public function hapusx($id_paket)
    {
        $this->db->where('id_paket', $id_paket);
        if($this->db->delete('tb_paket'))
           {return true;}
        else 
           {return false;}
           
    }



    
}