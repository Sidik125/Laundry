<?php
defined('BASEPATH') or exit('No direct script access allowed');

class m_outlet extends CI_Model
{
    public function tampil_data()
    {
        $this->db->order_by('id_outlet','desc');
        return $this->db->get('tb_outlet')->result();
    }
    public function daftarpengguna()
    {
        $this->db->where_in('role', ['Kasir']);
        return $this->db->get('tb_user')->result();
    }
    public function add_datax($data)
    {
        $data = 
        [
            'nama_outlet' => htmlspecialchars($this->input->post('nama_outlet', true)),
            'alamat' => htmlspecialchars($this->input->post('alamat',true)),
            'tlp' => ($this->input->post('tlp',true))
        ];

        $this->db->insert('tb_outlet',$data);
    }
    public function ubahx($id_outlet)
    {
        $data = 
        [
            'nama_outlet' => htmlspecialchars($this->input->post('nama_outlet', true)),
            'alamat' => htmlspecialchars($this->input->post('alamat',true)),
            'tlp' => ($this->input->post('tlp',true))
        ];
        // $tb_user = $this->db->dbprefix('tb_user');
        $this->db->where('id_outlet',$id_outlet);
        if($this->db->update('tb_outlet',$data))
           {return true;}
        else
           {return false;}

    }
    public function edit($id_outlet)
    {
        // $this->db->where_in('role', array('Kasir','Owner')); // filter admin  
        $this->db->where('id_outlet',$id_outlet);
        return $this->db->get('tb_outlet')->row_array();
    } 
    public function hapusx($id_outlet)
    {
        $this->db->where('id_outlet', $id_outlet);
        if($this->db->delete('tb_outlet'))
           {return true;}
        else
            {return false;}
    }

      



}