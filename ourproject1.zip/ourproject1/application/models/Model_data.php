<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_data extends CI_Model
{
    //Login
    function validate($email,$password)
    {
        $this->db->where('username',$email);
        $this->db->where('password',$password);
        $result = $this->db->get('tb_user',1);
        return $result;
    }
}