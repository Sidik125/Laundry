<?php
defined('BASEPATH') or exit('No direct script access allowed');

class m_laporan extends CI_Model
{
    public function tampil_data()
    {
        $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama_member');
        $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
        $this->db->from('tb_transaksi');
        $this->db->order_by('id_transaksi','desc');
        $query = $this->db->get();
        return $query->result();
    }
    public function outletx()
    {
        $this->db->select('tb_transaksi.*, tb_outlet.id_outlet, tb_outlet.nama_outlet');
        $this->db->join('tb_outlet', 'tb_transaksi.id_outlet = tb_outlet.id_outlet');
        $this->db->from('tb_transaksi');
        $this->db->order_by('id_transaksi','desc');
        $query = $this->db->get();
        return $query->result();
    } 
    public function daftarpelanggan()
    {
        return $this->db->get('tb_member')->result_array();
    }
    public function daftaroutlet() // looping outlet
    {
        return $this->db->get('tb_outlet')->result_array();
    }



}