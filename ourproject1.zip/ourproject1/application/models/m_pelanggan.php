<?php
defined('BASEPATH') or exit('No direct script access allowed');

class m_pelanggan extends CI_Model
{
    public function tampil_data()
    {
        $this->db->order_by('id_member','desc');
        return $this->db->get('tb_member')->result();

    }
    public function add_datax($data)
    {
        $data = 
        [
            'nama_member' => htmlspecialchars($this->input->post('nama_member', true)),
            'alamat' => htmlspecialchars($this->input->post('alamat',true)),
            'jenis_kelamin' => ($this->input->post('jenis_kelamin',true)),
            'tlp' => ($this->input->post('tlp',true))
        ];

        $this->db->insert('tb_member',$data);
    }
    public function ubahx($id_member)
    {
        $data = 
        [
            'nama_member' => htmlspecialchars($this->input->post('nama_member', true)),
            'alamat' => htmlspecialchars($this->input->post('alamat',true)),
            'jenis_kelamin' => ($this->input->post('jenis_kelamin',true)),
            'tlp' => ($this->input->post('tlp',true))
        ];
        // $tb_user = $this->db->dbprefix('tb_user');
        $this->db->where('id_member',$id_member);
        if($this->db->update('tb_member',$data))
           {return true;}
        else
           {return false;}

    }      
    public function edit($id_member)
    {
        // $this->db->where_in('role', array('Kasir','Owner')); // filter admin  
        $this->db->where('id_member',$id_member);
        return $this->db->get('tb_member')->row_array();
    } 

    public function hapusx($id_member)
    {
        $this->db->where('id_member', $id_member);
        if($this->db->delete('tb_member'))
           {return true;}
        else
            {return false;}
    }


    
}