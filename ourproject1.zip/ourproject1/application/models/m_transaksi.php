<?php
defined('BASEPATH') or exit('No direct script access allowed');

class m_transaksi extends CI_Model
{
    public function tampil_data()
    {
        $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama_member');
        $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
        $this->db->from('tb_transaksi');
        $this->db->order_by('id_transaksi','desc');
        $query = $this->db->get();
        return $query->result();

        // $this->db->order_by('id_transaksi','desc');
        // return $this->db->get('tb_transaksi')->result();
    }
    // javascript & no otomatis
    public function showall($tb, $prop) //kilo
    {
        //return $this->db->query("SELECT * FROM tb_paket WHERE id_paket =  $_POST[paket]")->row()l
        return $this->db->query("SELECT * FROM $tb $prop");
    }
    public function no()
    {
        return $this->db->query("SELECT max(kode_invoice) AS kode FROM tb_transaksi");
    }
    public function add_datax($data)
    {
        $data = 
        [
            'kode_invoice' => ($this->input->post('kode_invoice', true)),
            'id_member' => ($this->input->post('id_member',true)),
            'id_outlet' => ($this->input->post('id_outlet',true)),
            'id_paket' => ($this->input->post('id_paket',true)),
            'tgl' => ($this->input->post('tgl',true)),
            // 'tgl_ambil' => ($this->input->post('tgl_ambil',true)),
            'total_harga' => ($this->input->post('total_harga',true)),
            'status' => ($this->input->post('status',true)),
            // 'kembalian' => ($this->input->post('kembalian',true)),
            'jml_kilo' => ($this->input->post('jml_kilo',true))
        ];

        $this->db->insert('tb_transaksi',$data);
        
    }
    public function daftarpelanggan()
    {
        return $this->db->get('tb_member')->result_array();
    }
    public function daftarpaket()
    {
        return $this->db->get('tb_paket')->result_array();
    }
    public function daftaroutlet() // looping outlet
    {
        return $this->db->get('tb_outlet')->result_array();
    }
    public function ubahx($id_transaksi)
    {
        $data = 
        [
            'kode_invoice' => ($this->input->post('kode_invoice', true)),
            'id_member' => ($this->input->post('id_member',true)),
            'id_outlet' => ($this->input->post('id_outlet',true)),
            'id_paket' => ($this->input->post('id_paket',true)),
            'tgl' => ($this->input->post('tgl',true)),
            'tgl_ambil' => ($this->input->post('tgl_ambil',true)),
            'total_harga' => ($this->input->post('total_harga',true)),
            'status' => ($this->input->post('status',true)),
            'jml_kilo' => ($this->input->post('jml_kilo',true))
        ];
        // $tb_user = $this->db->dbprefix('tb_user');
        $this->db->where('id_transaksi',$id_transaksi);
        if($this->db->update('tb_transaksi',$data))
           {return true;}
        else
           {return false;}

    }
    public function edit($id_transaksi)
    {
        $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama_member');
        $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
        $this->db->from('tb_transaksi');
        $this->db->where('id_transaksi',$id_transaksi);
        return $this->db->get()->row_array();
    } 
    public function edit2($id_transaksi)
    {
        $this->db->select('tb_transaksi.*, tb_outlet.id_outlet, tb_outlet.nama_outlet');
        $this->db->join('tb_outlet', 'tb_transaksi.id_outlet = tb_outlet.id_outlet');
        $this->db->from('tb_transaksi');
        $this->db->where('id_transaksi',$id_transaksi);
        return $this->db->get()->row_array();
    } 
    public function edit3($id_transaksi)
    {
        $this->db->select('tb_transaksi.*, tb_paket.id_paket, tb_paket.nama_paket, tb_paket.harga');
        $this->db->join('tb_paket', 'tb_transaksi.id_paket = tb_paket.id_paket');
        $this->db->from('tb_transaksi');
        $this->db->where('id_transaksi',$id_transaksi);
        $query = $this->db->get();
        return $query->row_array();
    } 
      


    
}