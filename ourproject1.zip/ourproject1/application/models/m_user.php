<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_user extends CI_Model
{
    //show data
    public function tampilkan_data()
    {
        $this->db->where_in('role', array('Kasir','Owner')); //filter admin
        $this->db->order_by('id_user','desc');
        $query = $this->db->get('tb_user');
        return $query->result();
    }

    //tambah data
    public function add_data($data)
    {
        // $data = 
        // [
        //     'name' => htmlspecialchars($this->input->post('name', true)),
        //     'username' => htmlspecialchars($this->input->post('username',true)),
        //     'password' => md5($this->input->post('password',true)),
        //     'role_id' => ($this->input->post('role',true)),
        // ];
        $this->db->insert('tb_user',$data);
        
    }
    //edit data
    public function ubahx($id_user)
    {
        $data = 
        [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'username' => htmlspecialchars($this->input->post('username',true)),
            'password' => md5($this->input->post('password',true)),
            'role' => ($this->input->post('role',true))
        ];
        // $tb_user = $this->db->dbprefix('tb_user');
        $this->db->where('id_user',$id_user);
        if($this->db->update('tb_user',$data))
           {return true;}
        else
           {return false;}
           

    }
    public function edit($id_user)
    {
        $this->db->where_in('role', array('Kasir','Owner')); // filter admin  
        $this->db->where('id_user',$id_user);
        return $this->db->get('tb_user')->row_array();
    }


    //hapus data
    public function hapusx($id_user)
    {
        $this->db->where('id_user', $id_user);
        if($this->db->delete('tb_user'))
           {return true;}
        else 
           {return false;}
           
    }
}
