<!-- Begin Page Content -->
<div class="container-fluid">

<div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Data Pengguna</h6>
        </div>
    <div class="card-body">

        <form action="<?= base_url('User/ubah/'.$user['id_user']); ?>" method="post">
            <div class="form-group mb-2">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control" id="form-control" value="<?= $user['nama'];?>">
                <?= form_error('nama', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Username</label>
                <input type="text" name="username" class="form-control" id="inputPassword" value="<?= $user['username'];?>">
                <?= form_error('username', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Password</label>              
                <input type="password" name="password" class="form-control" id="inputPassword">
            </div>
            <div class="form-group mb-2">
                <label>Role</label>
                <select class="form-control" name="role" class="form-control" id="inputPassword">
                        <option value="<?= $user['role'];?>">"<?= $user['role'];?>"</option>
                        <option value=""></option>
                        <option value="Kasir">Kasir</option>
                        <option value="Owner">Owner</option>
                </select>
                <!-- <?= form_error('role', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'User/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>       
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> reset</button>
        </form>

    </div>
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Pengguna</h6>
        </div>

</div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 