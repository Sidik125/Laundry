<div class="content-wrapper">
    <div class="row gutters">
        <div class="col-lg-12">
            <h1 class="h3 mb-4 text-gray-800"><?= $judul;?></h1>
            ini berhasil
        </div>
    </div>
</div>
