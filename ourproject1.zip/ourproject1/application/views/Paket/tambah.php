<!-- Begin Page Content -->
<div class="container-fluid">

<div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><?= $judul; ?></h6>
        </div>
    <div class="card-body">

        <form action="<?= base_url('Paket/tambah_paket')?>" method="post">
            <div class="form-group mb-2">
                <label>Jenis Paket</label>
                <select class="form-control" name="jenis" class="form-control">
                        <option value="kiloan">kiloan</option>
                        <option value="selimut">selimut</option>
                        <option value="bed cover">bed cover</option>
                        <option value="kaos">kaos</option>
                        <option value="dll">dll</option>
                </select>
                <?= form_error('jenis paket', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Nama Paket</label>
                <input type="text" name="nama_paket" class="form-control">
                <?= form_error('nama paket', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Harga</label>
                <input type="number" name="harga" class="form-control">
                <!-- <?= form_error('harga', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'Paket/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> reset</button>
        </form>

    </div>
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><?= $judul; ?></h6>
        </div>

</div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 