<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale-1, shrink-to-fit=no">
    <title>Masuk</title>
    <link href="<?= base_url('assets/vendor/fontawesome-free/css/fontawesome.min.css'); ?>" rel="stylesheet">
    <link href="<?= base_url('assets/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?= base_url('assets/form.css'); ?>" rel="stylesheet">
</head>

<body id="body">
<div class="card position-absolute top-50 start-50 translate-middle" style="width: 30rem;">
         <div class="card-body">
            <h2 class="text-center">Masuk</h2>
            <br>
            <?= $this->session->flashdata('message'); ?>
            <form class="user" method="post" action="<?= base_url('login/masuk'); ?>" >

            <div class="form-group">
            <input type="text" class="form-control" id="email" name="email" placeholder="Masukan Email" value="<?= set_value('email'); ?>">
            <?= form_error('email','<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <br>
            <div class="form-group">
            <input type="password" class="form-control" id="password" name="password" placeholder="Masukan Password">
            <?= form_error('password','<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <br>
            <button type="submit" name="submit" class="btn btn-primary deep-purple btn-block ">Submit</button>
            </form>
        </div>
    </div>

    <script src="<?= base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"> </script>
</body>

</html>