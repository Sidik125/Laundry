<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" class="img/fav.png">

		<!-- datatables -->
		<link rel="stylesheet"  href="<?= base_url('assets/datatables/css/dataTables.bootstrap5.css'); ?>">
		<link rel="stylesheet"  href="<?= base_url('assets/datatables/css/jquery.dataTables.css'); ?>">
		<!-- <link rel="stylesheet" type="text/css" href="<?= base_url('assets/jquery/jquery-3.6.0.css'); ?>"> -->
		<!-- Title -->
		<title><?= $judul; ?></title>
		<!-- Bootstrap css -->
		<link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css')?>">
		<!-- Icomoon Font Icons css -->
		<link rel="stylesheet" href="<?= base_url('assets/fonts/style.css')?>">
		<link rel="stylesheet" href="<?= base_url('assets/vendor/fontawesome/css/all.min.css')?>">
		<!-- Main css -->
		<link rel="stylesheet" href="<?= base_url('assets/css/main.css')?>">
		<!-- Search Filter JS -->
		<link rel="stylesheet" href="<?= base_url('assets/vendor/search-filter/search-filter.css')?>">
		<link rel="stylesheet" href="<?= base_url('assets/vendor/search-filter/custom-search-filter.css')?>">
	</head>
	<body class="default-sidebar">

		<!-- Loading wrapper start -->
		<!-- <div id="loading-wrapper">
			<div class="spinner-border"></div>
		</div> -->
		<!-- Loading wrapper end -->

		<!-- Page wrapper start -->
		<div class="page-wrapper">
			<!-- Sidebar wrapper start -->
			<nav class="sidebar-wrapper">
				<!-- Default sidebar wrapper start -->
				<div class="default-sidebar-wrapper">
					<!-- Sidebar brand starts -->
					<div class="default-sidebar-brand">
						<a href="index.html" class="logo">
							<img src="<?= base_url('assets/img/ironing-board.png');?>" alt="Laundry Wangy">
							<h3 class="m-lg-3"> Wangyy </h3>
						</a>
					</div>
					<!-- Sidebar brand starts -->

					<!-- Sidebar menu starts -->
					<div class="defaultSidebarMenuScroll">
						<div class="default-sidebar-menu">
							<ul>
								<!--Admin-->
								<?php if ($this->session->userdata('role')=== 'Admin'):?>
								<li class="default-sidebar <?=$this->uri->segment(1) == 'Outlet' ? 'active' : null?>">
									<a href="<?= base_url('Outlet') ;?>">
										<i class="fas fa-store-alt"></i>
										<span class="menu-text">Outlet</span>
									</a>
								</li>	
								<li class="default-sidebar <?=$this->uri->segment(1) == 'Paket' ? 'active' : null?>">
									<a href="<?= base_url('Paket') ;?>">
										<i class="fas fa-box"></i>
										<span class="menu-text">Paket</span>
									</a>
								</li>	
								<li class="default-sidebar <?=$this->uri->segment(1) == 'Pelanggan' ? 'active' : null?>">
									<a href="<?= base_url('Pelanggan') ;?>">
										<i class="fas fa-users"></i>
										<span class="menu-text">Pelanggan</span>
									</a>
								</li>	
								<li class="default-sidebar <?=$this->uri->segment(1) == 'Transaksi' ? 'active' : null?>">
									<a href="<?= base_url('Transaksi') ;?>">
										<i class="fas fa-shopping-cart"></i>
										<span class="menu-text">Transaksi</span>
									</a>
								</li>	
								<li class="default-sidebar <?=$this->uri->segment(1) == 'User' ? 'active' : null?>">
									<a href=" <?= base_url('User'); ?> " >
										<i class="fas fa-user"></i>
										<span class="menu-text">Pengguna</span>
									</a>
								</li>
								<li class="default-sidebar <?=$this->uri->segment(1) == 'Laporan' ? 'active' : null?>">
									<a href="<?= base_url('Laporan') ;?>">
										<i class="fas fa-print"></i>
										<span class="menu-text">Laporan</span>
									</a>
								</li>
								<!-- kasir -->
								<?php elseif ($this->session->userdata('role')=== 'Kasir'):?>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'Pelanggan' ? 'active' : null?>">
									<a href="<?= base_url('Pelanggan') ;?>">
										<i class="fas fa-users"></i>
										<span class="menu-text">Pelanggan</span>
									</a>
								</li>	
								<li class="default-sidebar <?=$this->uri->segment(1) == 'Transaksi' ? 'active' : null?>">
									<a href="<?= base_url('Transaksi') ;?>">
										<i class="fas fa-shopping-cart"></i>
										<span class="menu-text">Transaksi</span>
									</a>
								</li>
								<li class="default-sidebar <?=$this->uri->segment(1) == 'Laporan' ? 'active' : null?>">
									<a href="<?= base_url('Laporan') ;?>">
										<i class="fas fa-print"></i>
										<span class="menu-text">Laporan</span>
									</a>
								</li>
								<!-- owner -->
								<?php else: ?>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'Laporan' ? 'active' : null?>">
									<a href="<?= base_url('Laporan') ;?>">
										<i class="fas fa-print"></i>
										<span class="menu-text">Laporan</span>
									</a>
								</li>
								<?php endif;?>
							</ul>
						</div>
					</div>
					<!-- Sidebar menu ends -->
				</div>
				<!-- Default sidebar wrapper end -->
			</nav>
			<!-- Sidebar wrapper end -->

			<div class="main-container">

				<!-- Page header starts -->
				<div class="page-header">
					
					<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-8 col-lg-8 col-md-8 col-sm-6 col-9">

							<!-- Search container start -->
							<div class="search-container">

								<!-- Toggle sidebar start -->
								<div class="toggle-sidebar" id="toggle-sidebar">
									<i class="icon-menu"></i>
								</div>
								<!-- Toggle sidebar end -->


								<!-- Search input group start -->
								<div class="ui fluid category search">
									<div class="ui icon input">
										<input class="prompt" type="text" placeholder="Search">
										<i class="search icon icon-search"></i>
									</div>
									<div class="results"></div>
								</div>
								<!-- Search input group end -->

							</div>
							<!-- Search container end -->

						</div>
						<div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-3">

							<!-- Header actions start -->
							<ul class="header-actions">
								<li>
									<span class="mr-5 d-none d-lg-inline text-gray-600 small"><?= $this->session->userdata('nama'); ?></span>
								</li>
								<li class="dropdown">
									<a href="#" id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
										<span class="avatar">
											<img src="<?= base_url('assets/img/user.svg');?>" alt="User Avatar">
										</span>
									</a>
									<div class="dropdown-menu dropdown-menu-end md" aria-labelledby="userSettings">
										<div class="header-profile-actions">
											<a href="<?= base_url('login/keluar')?>"><i class="icon-log-out1"></i>Logout</a>
										</div>
									</div>
								</li>
							</ul>
							<!-- Header actions end -->

						</div>
					</div>
					<!-- Row end -->					

				</div>
				<!-- Page header ends -->

				<!-- Content wrapper scroll start -->
				<div class="content-wrapper-scroll">

					<!-- Content wrapper start -->
					<div class="content-wrapper">

						<!-- Row start -->
						<?= $konten; ?>

						<!-- App Footer start -->
						<!-- App footer end -->
					</div>
					<!-- Content wrapper end -->
					
					<div class="app-footer">Copyright © Laundry Wangyy 2022</div>

				</div>
				<!-- Content wrapper scroll end -->

			</div>
		</div>
		<!-- Page wrapper end -->

		<!-- Required jQuery first, then Bootstrap Bundle JS -->
		<script src="<?= base_url('assets/js/jquery.min.js')?>"></script>
		<script src="<?= base_url('assets/js/modernizr.js')?>"></script>
		<script src="<?= base_url('assets/js/moment.js')?>"></script>
		
		
		<!-- Slimscroll JS -->
		<script src="vendor/slimscroll/slimscroll.min.js"></script>
		<script src="vendor/slimscroll/custom-scrollbar.js"></script>
		
		<!-- Search Filter JS -->
		<script src="vendor/search-filter/search-filter.js"></script>
		<script src="vendor/search-filter/custom-search-filter.js"></script>
		
		<!-- Main Js Required -->
		<script src="<?= base_url('assets/js/main.js')?>"></script>
		<!-- datatables -->
		<script src="<?= base_url('assets/bootstrap/js/bootstrap.bundle.js')?>"></script>
		<script src="<?= base_url('assets/datatables/js/dataTables.bootstrap5.js'); ?>"></script>
		<script src="<?= base_url('assets/datatables/js/jquery.dataTables.js'); ?>"></script>
		<!-- <script src="<?= base_url('assets/datatables/js/jquery-3.6.0.js'); ?>"></script> -->
        <script type="text/javascript">
	$(document).ready(function(){
		$('.dataTable').dataTable();
	});
</script>

         <script>
			 function kilo() //kilo
			 {
				 paket = $("#id_paket").val();
				 jml_kilo = $("#jml_kilo").val();
				 if (paket == "")
				 {
					 alert("Pilih Paket Terlebih Dahulu");
				 }
				 else
				 {
					 $.ajax
					 ({
						 url  : "<?= site_url('Transaksi/kilo') ?>",
						 type : "POST",
						 data : {
							 paket : paket,
							 jml_kilo :jml_kilo

						 },
						 success:function (data)
						 {
							 $("#total").val(data);
						 }
					 })
				 }
			 }
			 function printDiv(divName)
			 {
				 let printContents = document.getElementById(divName).innerHTML;
				 let originalContents = document.body.innerHTML;
				 document.body.innerHTML = printContents;
				 window.print();
				 document.body.innerHTML = originalContents;
				 location.reload(true);
				 setTimeout(function() {}, 50);
			 }
		 </script>
	</body>
</html>