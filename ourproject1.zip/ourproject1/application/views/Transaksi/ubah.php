<!-- Begin Page Content -->
<div class="container-fluid">

<div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><?= $judul; ?></h6>
        </div>
    <div class="card-body">
        
        <form action="<?= base_url('Transaksi/ubah/'.$transaksiv['id_transaksi']);?>" method="post">


            <div class="form-group mb-2">
                <label>Kode Inovice</label>
                <input type="text" name="kode_invoice" class="form-control" value="<?= $transaksiv['kode_invoice'];?>" readonly>
                <?= form_error('kode_invoice', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Pelanggan</label>
                <select class="form-control" name="id_member" readonly>
                    <option value="<?= $transaksiv['id_member']?>"><?= $transaksiv['nama_member']?></option>
                </select>
                <?= form_error('id_member', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Outlet</label>
                <select class="form-control" name="id_outlet" readonly>
                    <option value="<?= $transaksi2['id_outlet']?>"><?= $transaksi2['nama_outlet']?></option>
                </select>
                <?= form_error('id_outlet', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Tanggal Transaksi</label>
                <input type="date" name="tgl" class="form-control" value="<?= $transaksiv['tgl'];?>" readonly>
                <?= form_error('tgl', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Tanggal Ambil</label>
                <input type="date" name="tgl_ambil" class="form-control" value="<?= $transaksiv['tgl_ambil'];?>" >
                <!-- <?= form_error('tgl_ambil', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <div class="form-group mb-2">
                <label>Total Harga</label>
                <input type="number" name="total_harga" class="form-control" value="<?= $transaksiv['total_harga'];?>" readonly>
                <!-- <?= form_error('total_harga', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <div class="form-group mb-2">
                <label>Status</label>
                <select class="form-control" name="status" class="form-control">
                    <option value="<?= $transaksiv['status']?>"><?= $transaksiv['status']?></option>
                    <option value="">-</option>
                    <option value="baru">Baru</option>
                    <option value="proses">Proses</option>
                    <option value="selesai">Selesai</option>
                    <option value="diambil">Diambil</option>
                </select>
                <!-- <?= form_error('status', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <div class="form-group mb-2">
                <label>Paket</label>
                <select class="form-control" name="id_paket" >
                    <option value="    <?= $transaksi['id_paket'];?>     ">    <?= $transaksi['nama_paket'];?> ( Rp. <?= number_format($transaksi['harga'],0,",",",") ; ?> )</option>
                    <option value="">-</option>
                    <?php foreach ($paketv as $pv) { ?>
                        <option value="<?= $pv['id_paket'];?>"><?= $pv['nama_paket'];?> ( Rp. <?= number_format($pv['harga'],0,",",",") ; ?> )</option>
                    <?php } ; ?>
                </select>
                <!-- <?= form_error('id_paket', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <div class="form-group mb-2">
                <label>Jumlah Kilo</label>
                <input type="number" name="jml_kilo" class="form-control" value="<?= $transaksiv['jml_kilo'];?>">
                <!-- <?= form_error('jml_kilo', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'Transaksi/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
        </form>

    </div>
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><?= $judul; ?></h6>
        </div>

</div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 