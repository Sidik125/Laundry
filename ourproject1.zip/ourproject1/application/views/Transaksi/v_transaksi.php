    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>
    <?= $this->session->flashdata('Transaksi'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url('Transaksi/add') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah Transaksi</a>
        </div>

        <div class="card-body">
            <div class="table-responsive" id="print-area">

                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <colgroup>
                        <col width="2%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th>Kode Invoice</th>
                            <th>Pelanggan</th>
                            <th>Tanggal Transaksi</th>
                            <th>Tanggal Ambil</th>
                            <th>Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($transaksiv as $tv) : ?>
                            <tr>
                                <th class="text-center" scope="row"><?= $no; ?></th>
                                <td><?= $tv->kode_invoice; ?></td>
                                <td><?= $tv->nama_member; ?></td>
                                <td><?= $tv->tgl; ?></td>
                                <td><?= $tv->tgl_ambil; ?></td>
                                <td><?= $tv->status; ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url().'Transaksi/ubah/'.$tv->id_transaksi; ?>" class="btn btn-primary btn-flat btn-xs"><i class="fas fa-info-circle"></i> Details</a>
                                    <!-- <a href="<?php echo base_url().'Transaksi/hapus/'.$tv->id_transaksi; ?>" class="btn btn-danger btn-flat btn-xs"><i class="fa fa-trash"></i> Hapus</a> -->
                                </td>
                            </tr>
                            <?php $no++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <!-- <button onclick="printDiv('print-area')"></button> -->

            </div>
        </div>
    </div>

