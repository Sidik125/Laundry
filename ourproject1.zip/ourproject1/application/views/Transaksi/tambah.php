    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>
    <?= $this->session->flashdata('Transaksi'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
        </div>

        <div class="card-body">
            <form action="<?= base_url('Transaksi/add')?>" method="post">
    <div class="form-group mb-2">
        <label>Kode Inovice</label>
        <input type="text" name="kode_invoice" class="form-control" value="<?= $no ; ?>"readonly>
        <?= form_error('kode_invoice', '<small class="text-danger">', '</small> '); ?>
    </div>
    <div class="form-group mb-2">
        <label>Pelanggan</label>
        <select class="form-control" name="id_member" class="form-control">
        <?php foreach ($memberv as $mv) : ?>
        <option value="<?= $mv['id_member'];?>"><?= $mv['nama_member'];?></option>
        <?php endforeach; ?>
        </select>
        <?= form_error('id_member', '<small class="text-danger">', '</small> '); ?>
    </div>
    <div class="form-group mb-2">
        <label>Outlet</label>
        <select class="form-control" name="id_outlet" class="form-control">
        <?php foreach ($outletv as $ov) : ?>
        <option value="<?= $ov['id_outlet'];?>"><?= $ov['nama_outlet'];?></option>
        <?php endforeach; ?>
        </select>
        <?= form_error('id_outlet', '<small class="text-danger">', '</small> '); ?>
    </div>
    <div class="form-group mb-2">
        <label>Tanggal Transaksi</label>
        <input type="date" name="tgl" class="form-control">
        <?= form_error('tgl', '<small class="text-danger">', '</small> '); ?>
    </div>
    <div class="form-group mb-2">
        <label>Paket</label>
        <select class="form-control" name="id_paket" id="id_paket">
            <?php foreach ($paketv as $pv) { ?>
            <option value="<?= $pv['id_paket'];?>"><?= $pv['nama_paket'];?> ( Rp. <?= number_format($pv['harga'],0,",",",") ; ?> )</option>
            <?php } ; ?>
        </select>
        <!-- <?= form_error('id_paket', '<small class="text-danger">', '</small> '); ?> -->
    </div>
    <div class="form-group mb-2">
        <label>Total</label>
        <input type="number" name="total_harga" class="form-control" id="total" readonly>
    </div>
    <div class="form-group mb-2">
        <label>Jumlah Kilo</label>
        <input type="number" name="jml_kilo" class="form-control" id="jml_kilo" onkeyup="kilo()"> 
        <!-- <?= form_error('jml_kilo', '<small class="text-danger">', '</small> '); ?> -->
    </div>
    <div class="form-group mb-2">
        <label>Status</label>
        <select class="form-control" name="status" class="form-control" readonly>
            <option selected="">Baru</option>
        </select>
    </div>
    <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'Transaksi/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>
    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
    <button type="reset" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> reset</button>
</form>

        </div>
    </div>
