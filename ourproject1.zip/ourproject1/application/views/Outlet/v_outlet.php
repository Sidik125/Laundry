    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>
    <?= $this->session->flashdata('Outlet'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url('Outlet/add') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah Outlet</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">

                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <colgroup>
                        <col width="2%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th>Nama Outlet</th>
                            <th>Alamat</th>
                            <th>No.Telepon</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($outletv as $ov) : ?>
                            <tr>
                                <th class="text-center" scope="row"><?= $no; ?></th>
                                <td><?= $ov->nama_outlet; ?></td>
                                <td><?= $ov->alamat; ?></td>
                                <td><?= $ov->tlp; ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url().'Outlet/ubah/'.$ov->id_outlet; ?>" class="btn btn-primary btn-flat btn-xs"><i class="fa fa-pencil"></i> Ubah</a>
                                    <a class="btn btn-danger btn-flat btn-xs" data-bs-toggle="modal" data-bs-target="#hdp<?= $ov->id_outlet; ?>"><i class="fa fa-trash"></i>Hapus</a>
                                </td>
                            </tr>
                            <?php $no++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div> 


<!-- modal delete -->
<?php foreach ($outletv as $ov) { ?>
<?= form_open("Outlet/hapus"); ?>
<div class="modal fade" id="hdp<?= $ov->id_outlet; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
<div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><i class="fas fa-trash-alt"></i>&nbsp; Hapus data Outlet !</h5>
    </div>
    <div class="modal-body">
        <h4>Yakin ?</h4>
    </div>
    <input type="hidden" name="hapus" value="<?= $ov->id_outlet; ?>">
    <div class="modal-footer">
        <button type="submit" class="btn btn-danger btn-sm">Oke</button>
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
    </div>
    </div>
</div>
</div>
<?= form_close(); ?>
<?php } ; ?>
