    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>
    <?= $this->session->flashdata('Laporan'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
        </div>

        <div class="card-body">
            <div class="table-responsive" id="print-area">

                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <colgroup>
                        <col width="2%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th>Kode Invoice</th>
                            <th>Pelanggan</th>
                            <th>Outlet</th>
                            <th>Tanggal Transaksi</th>
                            <th>Tanggal Ambil</th>
                            <th>Total Harga</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($laporanv as $lv) : ?>
                            <tr>
                                <th class="text-center" scope="row"><?= $no; ?></th>
                                <td><?= $lv->kode_invoice; ?></td>
                                <td><?= $lv->nama_member; ?></td>
                                <td><?= $lv->id_outlet; ?></td>
                                <td><?= $lv->tgl; ?></td>
                                <td><?= $lv->tgl_ambil; ?></td>
                                <td><?= $lv->total_harga; ?></td>
                                <td><?= $lv->status; ?></td>
                                </td>
                            </tr>
                            <?php $no++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
                <button onclick="printDiv('print-area')" class="btn btn-primary btn-flat btn-xs"><i class="fas fa-print"></i>Print</button>
        </div>
    </div>
