    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>
    <?= $this->session->flashdata('Pelanggan'); ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="<?= base_url('Pelanggan/member_tambah') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah Member</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">

                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <colgroup>
                        <col width="2%">
                        <col width="15%">
                        <col width="15%">
                        <col width="5%">
                        <col width="15%">
                        <col width="15%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Jenis Kelamin</th>
                            <th>No.Telepon</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($memberv as $mv) : ?>
                            <tr>
                                <th class="text-center" scope="row"><?= $no; ?></th>
                                <td><?= $mv->nama_member; ?></td>
                                <td><?= $mv->alamat; ?></td>
                                <td><?= $mv->jenis_kelamin; ?></td>
                                <td><?= $mv->tlp; ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url().'Pelanggan/ubah/'.$mv->id_member; ?>" class="btn btn-primary btn-flat btn-xs"><i class="fa fa-pencil"></i> Ubah</a>
                                    <a class="btn btn-danger btn-flat btn-xs" data-bs-toggle="modal" data-bs-target="#hdp<?= $mv->id_member; ?>"><i class="fa fa-trash"></i>Hapus</a>
                                </td>
                            </tr>
                            <?php $no++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

<!-- modal delete -->
    <?php foreach ($memberv as $mv) { ?>
    <?= form_open("Pelanggan/hapus"); ?>
    <div class="modal fade" id="hdp<?= $mv->id_member; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel"><i class="fas fa-trash-alt"></i>&nbsp; Hapus data pelanggan !</h5>
        </div>
        <div class="modal-body">
            <h4>Yakin ?</h4>
        </div>
        <input type="hidden" name="hapus" value="<?= $mv->id_member; ?>">
        <div class="modal-footer">
            <button type="submit" class="btn btn-danger btn-sm">Oke</button>
            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
        </div>
        </div>
    </div>
    </div>
    <?= form_close(); ?>
    <?php } ; ?>
