<!-- Begin Page Content -->
<div class="container-fluid">

<div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Pelanggan</h6>
        </div>
    <div class="card-body">

        <form action="<?= base_url('Pelanggan/member_tambah')?>" method="post">
            <div class="form-group mb-2">
                <label>Nama</label>
                <input type="text" name="nama_member" class="form-control">
                <?= form_error('nama_member', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control">
                <?= form_error('alamat', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Jenis Kelamin</label>              
                <select class="form-control" name="jenis_kelamin" class="form-control">
                        <option value="L">Laki-Laki</option>
                        <option value="P">Perempuan</option>
                </select>
                <?= form_error('jenis_kelamin', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>No.Telepon</label>
                <input type="text" name="tlp" class="form-control">
                <!-- <?= form_error('nomor_telepon', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'Pelanggan/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> reset</button>
        </form>

    </div>
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Member</h6>
        </div>

</div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 