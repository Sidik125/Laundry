<!-- Begin Page Content -->
<div class="container-fluid">

<div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Data Pelanggan</h6>
        </div>
    <div class="card-body">

        <form action="<?= base_url('Pelanggan/ubah/'.$member['id_member']); ?>" method="post">
            <div class="form-group mb-2">
                <label>Nama</label>
                <input type="text" name="nama_member" class="form-control" id="form-control" value="<?= $member['nama_member'];?>">
                <?= form_error('nama_member', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control" id="form-control" value="<?= $member['alamat'];?>">
                <?= form_error('alamat', '<small class="text-danger">', '</small> '); ?>
            </div>
            <div class="form-group mb-2">
                <label>Jenis Kelamin</label>
                <select class="form-control" name="jenis_kelamin" class="form-control" id="form-control">
                    <option value="<?= $member['jenis_kelamin'];?>">"<?= $member['jenis_kelamin'];?>"</option>
                    <option value=""></option>
                    <option value="L">Laki-Laki</option>
                    <option value="P">Perempuan</option>
                </select>
                <!-- <?= form_error('jenis_kelamin', '<small class="text-danger">', '</small> '); ?> -->
            </div>
            <div class="form-group mb-2">
                <label>No.Telepon</label>              
                <input type="number" name="tlp" class="form-control" id="form-control" value="<?= $member['tlp'];?>">
            </div>
            <a class="btn btn-primary btn-sm" href="<?php echo base_url() . 'Pelanggan/' ?>" role="button"><i class="fa fa-arrow-left"></i>kembali</a>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
            <button type="reset" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> reset</button>
        </form>

    </div>
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Pengguna</h6>
        </div>

</div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 